#!/bin/bash -f
# This program requires the user to define the user ID as the
# first parameter and the file location that contains the
# hash as the second parameter.

# LIST is the list of characters to try
#----------------------------------------------------------------
SET1="A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"
SET2="0 1 2 3 4 5 6 7 8 9"
SET3="a b c d e f g h i j k l m n o p q r s t u v w x y z"
SET4="~ @ # $ % ^ * _ + - = { } [ ] ? ; :"
SET5="~ @ # $ % ^ * _ + - = { } [ ] ? ; :"
#----------------------------------------------------------------

#Function to get the SHA-512 password
#----------------------------------------------------------------
function sha512_crack(){
    echo "Cracking SHA-512 password"
    echo "-------------------------"

# Assign to the variable sha512_encr the encrypted password from the
# hash file
sha512_encr=`grep SHA512 vault.txt | cut -d":" -f2 | cut -d"$" -f4`

# Assign to the variable sha512_salt the salt used to generate the
# encrypted password
sha512_salt=`grep SHA512 vault.txt | cut -d":" -f2 | cut -d"$" -f3`

#set the start time of cracking process
before=`date`

# Assuming we know that the password is 5 alphanumeric long,
# So we need to iterate through all possible combinations of plaintext
# password, encrypt it (assign it to the variable test) and
# compare it to the encrypted password that was retrieved as
# the variable sha512 encr.
for i in $SET1
do
for j in $SET2
do
for k in $SET3
do
for l in $SET4
do
for m in $SET5
do
	#print out the password that is being compared   
	echo -n "$i$j$k$l$m "

	#it will encrypt the combination to a variable to compare with the sha512_encr
	sha512_test=`mkpasswd -m SHA-512 $i$j$k$l$m -s $sha512_salt | cut -d":" -f2 | cut -d"$" -f4`

		if [[ $sha512_test == $sha512_encr ]] ; then
			echo "                       "
			echo "Password is: $i$j$k$l$m"
			echo "The salt is: $sha512_salt"
			echo "Time start: $before"
			after=`date`
			echo "Time end: $after"
			exit
		fi
done
done
done
done
done
}

#Calling the function
sha512_crack

echo "Password not found"






