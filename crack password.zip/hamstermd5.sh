#!/bin/bash -f
# This program requires the user to define the user ID as the
# first parameter and the file location that contains the
# hash as the second parameter.

# SET is the list of characters to try
#----------------------------------------------------------------
SET1="A B C D E F G H I J K L M N O P Q R S T U V W X Y Z"
SET2="0 1 2 3 4 5 6 7 8 9"
SET3="a b c d e f g h i j k l m n o p q r s t u v w x y z"
SET4="~ @ # $ % ^ * _ + - = { } [ ] ? ; :"
SET5="~ @ # $ % ^ * _ + - = { } [ ] ? ; :"
#----------------------------------------------------------------

#Function to get the MD5 password
function md5_crack(){
    echo "Cracking MD5 password"
    echo "-------------------------"

# Assign to the variable md5_encr the encrypted password from the
# hash file
md5_encr=`grep MD5 vault.txt | cut -d":" -f2 | cut -d"$" -f4`

# Assign to the variable md5_salt the salt used to generate the
# encrypted password
md5_salt=`grep MD5 vault.txt | cut -d":" -f2 | cut -d"$" -f3`

#set the start time of cracking process
before=`date`

# Assuming we know that the password is 5 alphanumeric long,
# So we need to iterate through all possible combinations of plaintext
# password, encrypt it (assign it to the variable test) and
# compare it to the encrypted password that was retrieved as
# the variable md5_encr.
for i in $SET1
do
for j in $SET2
do
for k in $SET3
do
for l in $SET4
do
for m in $SET5
do
	#print out the password that is being compared
	echo -n "$i$j$k$l$m "
	
	#it will encrypt the combination to a variable to compare with the md5_encr	   
	md5_test=`mkpasswd -m md5 $i$j$k$l$m -s $md5_salt | cut -d":" -f2 | cut -d"$" -f4`

						if [[ $md5_test == $md5_encr ]] ; then
							echo "                       "
							echo "Password is: $i$j$k$l$m"
							echo "The salt is: $md5_salt"
							echo "Time start: $before"
							after=`date`
							echo "Time end: $after"
			    				exit
						fi
done
done
done
done
done
}

#Calling the function
md5_crack

echo "Password not found"






